# SVG Card background CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/jamers08/pen/XWPVLVR](https://codepen.io/jamers08/pen/XWPVLVR).

